package com.soalscan.app

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** Pembaca teks dari gambar (ML Kit, berjalan di perangkat / offline). */
object Ocr {
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    fun recognize(bitmap: Bitmap, onDone: (Result<String>) -> Unit) {
        // Crop yang kecil diperbesar supaya huruf kecil lebih mudah terbaca.
        val src = upscaleIfSmall(bitmap)
        try {
            recognizer.process(InputImage.fromBitmap(src, 0))
                .addOnSuccessListener { onDone(Result.success(clean(it.text))) }
                .addOnFailureListener { onDone(Result.failure(it)) }
        } catch (e: Exception) {
            onDone(Result.failure(e))
        }
    }

    private fun upscaleIfSmall(b: Bitmap): Bitmap {
        val minSide = minOf(b.width, b.height)
        if (minSide >= 700) return b
        val f = (700f / minSide).coerceAtMost(3f)
        return Bitmap.createScaledBitmap(b, (b.width * f).toInt(), (b.height * f).toInt(), true)
    }

    private fun clean(t: String): String =
        t.replace("\r", "")
            .replace(Regex("[ \\t]+\\n"), "\n")
            .replace(Regex("\\n{3,}"), "\n\n")
            .trim()
}
