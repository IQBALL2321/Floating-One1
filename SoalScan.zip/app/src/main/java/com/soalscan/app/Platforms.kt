package com.soalscan.app

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import java.net.URLEncoder

/** Satu tujuan pengiriman teks soal (mesin pencari / platform AI). */
data class Platform(
    val id: String,
    val name: String,
    val emoji: String,
    /** true = platform tidak menerima teks lewat URL, jadi teks disalin ke clipboard lalu halaman dibuka. */
    val copyFirst: Boolean = false,
    /** true = tambahkan perintah "Jawab soal berikut..." di depan teks. */
    val aiPrompt: Boolean = false,
    val url: (encodedText: String) -> String
)

object Platforms {
    const val PROMPT = "Jawab soal berikut dengan jelas dan beri penjelasan singkat:\n\n"
    private const val MAX_URL_TEXT = 1800

    val all: List<Platform> = listOf(
        Platform("google_ai", "Google AI Mode", "✨") { "https://www.google.com/search?q=$it&udm=50" },
        Platform("google", "Google Search", "🔍") { "https://www.google.com/search?q=$it" },
        Platform("chatgpt", "ChatGPT", "💬", aiPrompt = true) { "https://chatgpt.com/?q=$it" },
        Platform("perplexity", "Perplexity", "🔎", aiPrompt = true) { "https://www.perplexity.ai/search?q=$it" },
        Platform("copilot", "Copilot", "🧭", aiPrompt = true) { "https://copilot.microsoft.com/?q=$it" },
        Platform("claude", "Claude", "🟠", aiPrompt = true) { "https://claude.ai/new?q=$it" },
        Platform("gemini", "Gemini", "♊", copyFirst = true, aiPrompt = true) { "https://gemini.google.com/app" },
        Platform("translate", "Google Translate", "🌐") { "https://translate.google.com/?sl=auto&tl=id&op=translate&text=$it" },
    )

    fun open(ctx: Context, p: Platform, rawText: String, usePrompt: Boolean) {
        val text = rawText.trim()
        if (text.isEmpty()) {
            Toast.makeText(ctx, "Teks kosong", Toast.LENGTH_SHORT).show()
            return
        }
        Prefs.setLastPlatform(ctx, p.id)
        val finalText = if (usePrompt && p.aiPrompt) PROMPT + text else text
        if (p.copyFirst) {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("soal", finalText))
            Toast.makeText(ctx, "Soal disalin. Tempel (paste) di ${p.name}", Toast.LENGTH_LONG).show()
        }
        val enc = URLEncoder.encode(finalText.take(MAX_URL_TEXT), "UTF-8")
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(p.url(enc))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(ctx, "Tidak ada aplikasi untuk membuka tautan", Toast.LENGTH_SHORT).show()
        }
    }
}
