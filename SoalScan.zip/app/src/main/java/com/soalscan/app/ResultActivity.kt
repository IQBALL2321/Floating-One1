package com.soalscan.app

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

/** Menampilkan hasil OCR (bisa diedit) dan tombol kirim ke Google / platform AI. */
class ResultActivity : Activity() {

    companion object {
        const val EXTRA_TEXT = "text"
        const val EXTRA_IMAGE = "image"
    }

    private lateinit var edit: EditText
    private lateinit var promptCheck: CheckBox
    private var imagePath: String? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Hasil scan soal"
        imagePath = intent.getStringExtra(EXTRA_IMAGE)
        buildUi(intent.getStringExtra(EXTRA_TEXT) ?: "")
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        recreate()
    }

    private fun buildUi(text: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(32))
        }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)

        // pratinjau gambar soal
        imagePath?.let { p ->
            val bmp = BitmapFactory.decodeFile(p)
            if (bmp != null) {
                val iv = ImageView(this).apply {
                    setImageBitmap(bmp)
                    adjustViewBounds = true
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    maxHeight = dp(170)
                }
                root.addView(iv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) })
            }
        }

        if (text.isBlank()) {
            root.addView(TextView(this).apply {
                this.text = "Teks tidak terbaca. Ketik soalnya di bawah, atau bagikan gambarnya langsung ke aplikasi AI (cocok untuk rumus dan gambar)."
                setTextColor(0xFFF59E0B.toInt())
                textSize = 13f
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) })
        }

        root.addView(TextView(this).apply {
            this.text = "Teks soal (bisa diedit sebelum dikirim)"
            setTypeface(typeface, Typeface.BOLD)
        })
        edit = EditText(this).apply {
            setText(text)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 5
            gravity = android.view.Gravity.TOP
            textSize = 15f
        }
        root.addView(edit, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) })

        promptCheck = CheckBox(this).apply {
            this.text = "Tambahkan perintah \"Jawab soal berikut...\" untuk platform AI"
            isChecked = Prefs.usePrompt(this@ResultActivity)
            setOnCheckedChangeListener { _, v -> Prefs.setUsePrompt(this@ResultActivity, v) }
        }
        root.addView(promptCheck)

        // bagikan gambar langsung ke aplikasi AI (paling akurat untuk rumus / diagram)
        if (imagePath != null) {
            addButton(root, "🖼️ Bagikan GAMBAR soal ke aplikasi AI (ChatGPT / Gemini / Claude)", true) { shareImage() }
        }

        root.addView(TextView(this).apply {
            this.text = "Kirim TEKS ke:"
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(12), 0, dp(4))
        })

        val last = Prefs.lastPlatform(this)
        val ordered = Platforms.all.sortedByDescending { it.id == last }
        for (p in ordered) {
            val label = p.emoji + "  " + p.name + if (p.id == last) "  ★ terakhir dipakai" else ""
            addButton(root, label, p.id == last) {
                Platforms.open(this, p, edit.text.toString(), promptCheck.isChecked)
            }
        }

        addButton(root, "📋 Salin teks", false) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("soal", edit.text.toString()))
            Toast.makeText(this, "Teks disalin", Toast.LENGTH_SHORT).show()
        }
        addButton(root, "Tutup", false) { finish() }
    }

    private fun addButton(root: LinearLayout, label: String, primary: Boolean, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            isAllCaps = false
            gravity = android.view.Gravity.START or android.view.Gravity.CENTER_VERTICAL
            if (primary) {
                setBackgroundColor(0xFF0EA5E9.toInt())
                setTextColor(Color.WHITE)
            }
            setOnClickListener { action() }
        }
        root.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
    }

    private fun shareImage() {
        val path = imagePath ?: return
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", File(path))
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "image/jpeg"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, "Tolong jawab soal pada gambar ini dengan jelas dan beri penjelasan singkat.")
                clipData = ClipData.newRawUri("soal", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(send, "Kirim gambar soal ke..."))
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal membagikan gambar: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
