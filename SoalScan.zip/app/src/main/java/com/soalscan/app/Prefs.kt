package com.soalscan.app

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("soalscan", Context.MODE_PRIVATE)

    fun bubbleOn(c: Context) = sp(c).getBoolean("bubble_on", true)
    fun setBubbleOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("bubble_on", v).apply()

    /** Ukuran bubble dalam dp (40..80). */
    fun bubbleSize(c: Context) = sp(c).getInt("bubble_size", 56)
    fun setBubbleSize(c: Context, v: Int) = sp(c).edit().putInt("bubble_size", v).apply()

    /** Transparansi bubble dalam persen (30..100). */
    fun bubbleAlpha(c: Context) = sp(c).getInt("bubble_alpha", 80)
    fun setBubbleAlpha(c: Context, v: Int) = sp(c).edit().putInt("bubble_alpha", v).apply()

    fun bubbleX(c: Context) = sp(c).getInt("bubble_x", 0)
    fun bubbleY(c: Context) = sp(c).getInt("bubble_y", 400)
    fun setBubblePos(c: Context, x: Int, y: Int) = sp(c).edit().putInt("bubble_x", x).putInt("bubble_y", y).apply()

    fun lastPlatform(c: Context): String? = sp(c).getString("last_platform", null)
    fun setLastPlatform(c: Context, id: String) = sp(c).edit().putString("last_platform", id).apply()

    fun usePrompt(c: Context) = sp(c).getBoolean("use_prompt", true)
    fun setUsePrompt(c: Context, v: Boolean) = sp(c).edit().putBoolean("use_prompt", v).apply()
}
