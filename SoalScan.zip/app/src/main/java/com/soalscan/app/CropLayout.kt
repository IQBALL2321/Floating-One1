package com.soalscan.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Layar penuh berisi screenshot beku + kotak seleksi yang bisa digeser / diubah ukurannya.
 * Tombol centang (✓) mengambil bagian yang dipilih.
 */
class CropLayout(
    context: Context,
    private val bitmap: Bitmap,
    private val onConfirm: (Bitmap) -> Unit,
    private val onCancel: () -> Unit
) : FrameLayout(context) {

    private val cropView = CropView(context, bitmap)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    init {
        setBackgroundColor(Color.BLACK)
        addView(cropView, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        val hint = TextView(context).apply {
            text = "Geser kotak ke soal, tarik sudutnya untuk mengatur, lalu tekan ✓"
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(0xAA000000.toInt())
            gravity = Gravity.CENTER
        }
        addView(hint, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.TOP
            topMargin = dp(40)
        })

        val bar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        fun btn(label: String, bg: Int, w: Int, action: () -> Unit) = Button(context).apply {
            text = label
            textSize = 20f
            setTextColor(Color.WHITE)
            setBackgroundColor(bg)
            setOnClickListener { action() }
        }.also {
            bar.addView(it, LinearLayout.LayoutParams(dp(w), dp(56)).apply { marginStart = dp(8); marginEnd = dp(8) })
        }

        btn("✕", 0xFFB91C1C.toInt(), 72) { onCancel() }
        btn("Seluruh layar", 0xFF475569.toInt(), 130) { cropView.selectAll() }
        btn("✓", 0xFF16A34A.toInt(), 72) {
            val b = cropView.croppedBitmap()
            if (b == null) {
                Toast.makeText(context, "Pilih area soal dulu (kotak terlalu kecil)", Toast.LENGTH_SHORT).show()
            } else {
                onConfirm(b)
            }
        }

        addView(bar, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.BOTTOM
            bottomMargin = dp(48)
        })
    }
}

private class CropView(context: Context, private val bmp: Bitmap) : View(context) {
    private val img = RectF()
    private val sel = RectF()
    private val dimPaint = Paint().apply { color = 0x99000000.toInt() }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF22D3EE.toInt(); style = Paint.Style.STROKE; strokeWidth = dp(2f)
    }
    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF22D3EE.toInt() }

    private var mode = 0 // 0 = tidak ada, 1 = geser kotak, 2 = ubah ukuran / buat baru
    private var ax = 0f
    private var ay = 0f
    private var lx = 0f
    private var ly = 0f

    private fun dp(v: Float) = v * resources.displayMetrics.density

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val s = min(w / bmp.width.toFloat(), h / bmp.height.toFloat())
        val dw = bmp.width * s
        val dh = bmp.height * s
        img.set((w - dw) / 2f, (h - dh) / 2f, (w + dw) / 2f, (h + dh) / 2f)
        sel.set(
            img.left + img.width() * 0.08f,
            img.top + img.height() * 0.30f,
            img.right - img.width() * 0.08f,
            img.top + img.height() * 0.55f
        )
    }

    fun selectAll() {
        sel.set(img)
        invalidate()
    }

    fun croppedBitmap(): Bitmap? {
        if (sel.width() < dp(24f) || sel.height() < dp(24f)) return null
        val sc = bmp.width / img.width()
        val l = ((sel.left - img.left) * sc).toInt().coerceIn(0, bmp.width - 1)
        val t = ((sel.top - img.top) * sc).toInt().coerceIn(0, bmp.height - 1)
        val w = (sel.width() * sc).toInt().coerceIn(1, bmp.width - l)
        val h = (sel.height() * sc).toInt().coerceIn(1, bmp.height - t)
        return Bitmap.createBitmap(bmp, l, t, w, h)
    }

    override fun onDraw(c: Canvas) {
        c.drawBitmap(bmp, null, img, null)
        c.drawRect(img.left, img.top, img.right, sel.top, dimPaint)
        c.drawRect(img.left, sel.bottom, img.right, img.bottom, dimPaint)
        c.drawRect(img.left, sel.top, sel.left, sel.bottom, dimPaint)
        c.drawRect(sel.right, sel.top, img.right, sel.bottom, dimPaint)
        c.drawRect(sel, borderPaint)
        val r = dp(8f)
        c.drawCircle(sel.left, sel.top, r, handlePaint)
        c.drawCircle(sel.right, sel.top, r, handlePaint)
        c.drawCircle(sel.left, sel.bottom, r, handlePaint)
        c.drawCircle(sel.right, sel.bottom, r, handlePaint)
    }

    private fun clampX(x: Float) = x.coerceIn(img.left, img.right)
    private fun clampY(y: Float) = y.coerceIn(img.top, img.bottom)

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x
        val y = e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val touch = dp(32f)
                val corners = arrayOf(
                    floatArrayOf(sel.left, sel.top), floatArrayOf(sel.right, sel.top),
                    floatArrayOf(sel.left, sel.bottom), floatArrayOf(sel.right, sel.bottom)
                )
                var hit = -1
                for (i in corners.indices) {
                    if (hypot(x - corners[i][0], y - corners[i][1]) < touch) hit = i
                }
                if (hit >= 0) {
                    ax = if (hit % 2 == 0) sel.right else sel.left
                    ay = if (hit < 2) sel.bottom else sel.top
                    mode = 2
                } else if (sel.contains(x, y)) {
                    mode = 1
                    lx = x
                    ly = y
                } else {
                    ax = clampX(x)
                    ay = clampY(y)
                    sel.set(ax, ay, ax, ay)
                    mode = 2
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (mode == 2) {
                    val cx = clampX(x)
                    val cy = clampY(y)
                    sel.set(min(ax, cx), min(ay, cy), max(ax, cx), max(ay, cy))
                } else if (mode == 1) {
                    val dx = x - lx
                    val dy = y - ly
                    val nl = (sel.left + dx).coerceIn(img.left, img.right - sel.width())
                    val nt = (sel.top + dy).coerceIn(img.top, img.bottom - sel.height())
                    sel.offsetTo(nl, nt)
                    lx = x
                    ly = y
                }
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> mode = 0
        }
        return true
    }
}
