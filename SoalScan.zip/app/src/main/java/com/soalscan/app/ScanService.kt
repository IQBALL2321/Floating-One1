package com.soalscan.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.ImageView
import android.widget.Toast
import kotlin.math.abs

/**
 * Service aksesibilitas yang:
 *  1. menampilkan bubble melayang (tanpa izin "tampil di atas aplikasi lain"),
 *  2. mengambil screenshot saat bubble disentuh (AccessibilityService.takeScreenshot),
 *  3. menampilkan kotak seleksi + centang, lalu menjalankan OCR pada area yang dipilih.
 */
class ScanService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ScanService? = null
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var bubble: View? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var cropLayout: View? = null
    private var busy = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (Prefs.bubbleOn(this)) showBubble()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        removeCrop()
        removeBubble()
        instance = null
        return super.onUnbind(intent)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun screenWidth() = wm.currentWindowMetrics.bounds.width()

    fun showBubble() {
        if (bubble != null) return
        val size = dp(Prefs.bubbleSize(this))
        val view = ImageView(this).apply {
            setImageResource(R.drawable.ic_bubble)
            setBackgroundResource(R.drawable.bubble_bg)
            setPadding(size / 4, size / 4, size / 4, size / 4)
            alpha = Prefs.bubbleAlpha(this@ScanService) / 100f
            contentDescription = "Scan soal"
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = Prefs.bubbleX(this@ScanService)
            y = Prefs.bubbleY(this@ScanService)
        }
        view.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0
            var startY = 0
            var touchX = 0f
            var touchY = 0f
            var moved = false
            val slop = dp(6)

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = lp.x; startY = lp.y
                        touchX = e.rawX; touchY = e.rawY
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - touchX).toInt()
                        val dy = (e.rawY - touchY).toInt()
                        if (abs(dx) > slop || abs(dy) > slop) moved = true
                        if (moved) {
                            lp.x = startX + dx
                            lp.y = startY + dy
                            wm.updateViewLayout(v, lp)
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) {
                            captureAndCrop()
                        } else {
                            // tempel ke tepi layar terdekat
                            lp.x = if (lp.x + lp.width / 2 < screenWidth() / 2) 0 else screenWidth() - lp.width
                            wm.updateViewLayout(v, lp)
                            Prefs.setBubblePos(this@ScanService, lp.x, lp.y)
                        }
                    }
                }
                return true
            }
        })
        wm.addView(view, lp)
        bubble = view
        bubbleLp = lp
    }

    fun hideBubble() = removeBubble()

    fun refreshBubble() {
        removeBubble()
        if (Prefs.bubbleOn(this)) showBubble()
    }

    private fun removeBubble() {
        bubble?.let { runCatching { wm.removeView(it) } }
        bubble = null
        bubbleLp = null
    }

    private fun removeCrop() {
        cropLayout?.let { runCatching { wm.removeView(it) } }
        cropLayout = null
    }

    private fun captureAndCrop() {
        if (busy) return
        busy = true
        bubble?.visibility = View.INVISIBLE // sembunyikan bubble supaya tidak ikut ter-screenshot
        handler.postDelayed({
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(screenshot: ScreenshotResult) {
                    val hw = screenshot.hardwareBuffer
                    val bmp = Bitmap.wrapHardwareBuffer(hw, screenshot.colorSpace)
                        ?.copy(Bitmap.Config.ARGB_8888, false)
                    hw.close()
                    bubble?.visibility = View.VISIBLE
                    if (bmp == null) {
                        busy = false
                        Toast.makeText(this@ScanService, "Gagal membaca screenshot", Toast.LENGTH_SHORT).show()
                    } else {
                        showCrop(bmp)
                    }
                }

                override fun onFailure(errorCode: Int) {
                    bubble?.visibility = View.VISIBLE
                    busy = false
                    Toast.makeText(
                        this@ScanService,
                        "Screenshot gagal (kode $errorCode). Tunggu 1 detik lalu coba lagi; layar yang dilindungi tidak bisa di-screenshot.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            })
        }, 200)
    }

    private fun showCrop(bmp: Bitmap) {
        removeCrop()
        val layout = CropLayout(
            this, bmp,
            onConfirm = { cropped ->
                removeCrop()
                busy = false
                ScanFlow.process(this, cropped)
            },
            onCancel = {
                removeCrop()
                busy = false
            }
        )
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        wm.addView(layout, lp)
        cropLayout = layout
    }
}
