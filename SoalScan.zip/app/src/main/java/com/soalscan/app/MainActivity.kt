package com.soalscan.app

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CompoundButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

class MainActivity : Activity() {

    private companion object {
        const val REQ_GALLERY = 1
        const val REQ_CAMERA = 2
    }

    private lateinit var status: TextView
    private lateinit var bubbleSwitch: Switch
    private var cameraFile: File? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Soal Scan"
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(32))
        }
        setContentView(ScrollView(this).apply { addView(root) })

        root.addView(text("Soal Scan", 24f, bold = true))
        root.addView(text("Scan soal berbentuk gambar langsung dari layar: sentuh bubble, pilih area soal, tekan ✓, lalu kirim ke Google atau platform AI.", 14f))

        root.addView(section("1. Aktifkan layanan"))
        status = text("", 14f)
        root.addView(status)
        root.addView(button("Buka Pengaturan Aksesibilitas") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(text(
            "Cari \"Soal Scan\" lalu aktifkan. Jika tombolnya abu-abu dan muncul pesan \"Pengaturan dibatasi\" " +
                "(biasa terjadi untuk APK dari luar Play Store): buka Info Aplikasi Soal Scan → menu ⋮ di kanan atas → " +
                "\"Izinkan pengaturan dibatasi\", lalu ulangi.", 12f
        ))
        root.addView(button("Buka Info Aplikasi") {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        })

        root.addView(section("2. Bubble"))
        bubbleSwitch = Switch(this).apply {
            text = "Tampilkan bubble"
            isChecked = Prefs.bubbleOn(this@MainActivity)
            setOnCheckedChangeListener { _: CompoundButton, v: Boolean ->
                Prefs.setBubbleOn(this@MainActivity, v)
                val s = ScanService.instance
                if (s == null) {
                    if (v) Toast.makeText(this@MainActivity, "Aktifkan dulu di Pengaturan Aksesibilitas", Toast.LENGTH_LONG).show()
                } else if (v) s.showBubble() else s.hideBubble()
            }
        }
        root.addView(bubbleSwitch)

        root.addView(text("Ukuran bubble", 13f))
        root.addView(seek(40, 80, Prefs.bubbleSize(this)) { v ->
            Prefs.setBubbleSize(this, v); ScanService.instance?.refreshBubble()
        })
        root.addView(text("Transparansi bubble", 13f))
        root.addView(seek(30, 100, Prefs.bubbleAlpha(this)) { v ->
            Prefs.setBubbleAlpha(this, v); ScanService.instance?.refreshBubble()
        })

        root.addView(section("3. Scan dari foto (tanpa bubble)"))
        root.addView(button("🖼️ Pilih foto dari galeri") {
            val i = Intent(Intent.ACTION_GET_CONTENT).apply {
                type = "image/*"
                addCategory(Intent.CATEGORY_OPENABLE)
            }
            startActivityForResult(Intent.createChooser(i, "Pilih foto soal"), REQ_GALLERY)
        })
        root.addView(button("📷 Ambil foto dengan kamera") { openCamera() })

        root.addView(section("Catatan"))
        root.addView(text(
            "• Butuh Android 11 atau lebih baru.\n" +
                "• Aplikasi yang melarang screenshot (mis. ujian atau perbankan tertentu) tidak bisa di-scan lewat bubble; gunakan foto dari kamera.\n" +
                "• OCR membaca teks cetak dengan baik, tapi rumus dan diagram sering salah. Untuk itu pakai tombol \"Bagikan GAMBAR soal\" di layar hasil.\n" +
                "• Scan berjalan di perangkat. Data hanya keluar saat Anda memilih platform pencarian / AI.", 12f
        ))
    }

    override fun onResume() {
        super.onResume()
        val on = ScanService.instance != null
        status.text = if (on) "✓ Layanan aktif" else "✗ Layanan belum aktif"
        status.setTextColor(if (on) 0xFF16A34A.toInt() else 0xFFDC2626.toInt())
    }

    private fun openCamera() {
        try {
            val dir = File(cacheDir, "shots").apply { mkdirs() }
            val f = File(dir, "camera.jpg")
            cameraFile = f
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                putExtra(MediaStore.EXTRA_OUTPUT, uri)
                addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivityForResult(i, REQ_CAMERA)
        } catch (e: Exception) {
            Toast.makeText(this, "Kamera tidak tersedia: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        try {
            val uri: Uri? = when (requestCode) {
                REQ_GALLERY -> data?.data
                REQ_CAMERA -> cameraFile?.let { FileProvider.getUriForFile(this, "$packageName.fileprovider", it) }
                else -> null
            }
            if (uri == null) return
            ScanFlow.process(this, decode(uri))
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal membuka gambar: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun decode(uri: Uri): Bitmap {
        val src = ImageDecoder.createSource(contentResolver, uri)
        return ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val m = maxOf(info.size.width, info.size.height)
            if (m > 2600) {
                val r = 2600f / m
                decoder.setTargetSize((info.size.width * r).toInt(), (info.size.height * r).toInt())
            }
        }
    }

    // ---------- helper UI ----------
    private fun text(t: String, size: Float, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(4), 0, dp(4))
    }

    private fun section(t: String) = text(t, 16f, bold = true).apply { setPadding(0, dp(18), 0, dp(4)) }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        gravity = Gravity.START or Gravity.CENTER_VERTICAL
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun seek(lo: Int, hi: Int, value: Int, onChange: (Int) -> Unit) = SeekBar(this).apply {
        this.max = hi - lo
        progress = value - lo
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) onChange(p + lo)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }
}
