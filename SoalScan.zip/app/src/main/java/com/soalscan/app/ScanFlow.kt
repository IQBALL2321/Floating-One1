package com.soalscan.app

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

/** Alur bersama: simpan gambar soal -> OCR -> buka layar hasil. */
object ScanFlow {

    fun process(ctx: Context, bmp: Bitmap) {
        Toast.makeText(ctx, "Membaca soal...", Toast.LENGTH_SHORT).show()
        val path = save(ctx, bmp)
        Ocr.recognize(bmp) { result ->
            val text = result.getOrDefault("")
            val i = Intent(ctx, ResultActivity::class.java)
                .putExtra(ResultActivity.EXTRA_TEXT, text)
                .putExtra(ResultActivity.EXTRA_IMAGE, path)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        }
    }

    private fun save(ctx: Context, bmp: Bitmap): String {
        val dir = File(ctx.cacheDir, "shots").apply { mkdirs() }
        // bersihkan file lama (simpan 5 terakhir)
        dir.listFiles { f -> f.name.startsWith("soal_") }
            ?.sortedByDescending { it.lastModified() }
            ?.drop(5)
            ?.forEach { it.delete() }
        val f = File(dir, "soal_${System.currentTimeMillis()}.jpg")
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        return f.absolutePath
    }
}
