# Soal Scan

Aplikasi Android dengan bubble melayang untuk **scan soal berbentuk gambar langsung dari layar**.

Alur: sentuh bubble → layar dibekukan → geser kotak ke area soal → tekan **✓** → teks soal dibaca (OCR) →
kirim ke Google AI Mode, Google Search, ChatGPT, Perplexity, Copilot, Claude, Gemini, atau Google Translate.
Tombol **Bagikan GAMBAR soal** mengirim gambarnya langsung ke aplikasi AI (paling akurat untuk rumus/diagram).

Yang dibutuhkan: Android 11+ (API 30).

## Cara membuat APK

### A. Dari HP saja (GitHub Actions, gratis)
1. Buat akun & repository baru di github.com (boleh private).
2. Upload SELURUH isi folder ini (termasuk folder `.github`) ke repository. Di web GitHub: Add file → Upload files.
   Jika folder `.github` tidak ikut terunggah, buat manual file `.github/workflows/build.yml` dan salin isinya.
3. Buka tab **Actions** → workflow **Build APK** → **Run workflow**.
4. Setelah hijau (± 5–8 menit), buka run-nya → bagian **Artifacts** → unduh **SoalScan-debug-apk** → ekstrak → `app-debug.apk`.

### B. Dari komputer (Android Studio)
1. Install Android Studio (Hedgehog atau lebih baru).
2. File → Open → pilih folder ini → tunggu Gradle sync.
3. Build → Build APK(s). Hasil: `app/build/outputs/apk/debug/app-debug.apk`.

## Cara memakai
1. Pasang APK, buka aplikasi.
2. Tekan **Buka Pengaturan Aksesibilitas** → aktifkan **Soal Scan**.
   Jika tombolnya abu-abu (APK dari luar Play Store): Info Aplikasi → menu ⋮ → **Izinkan pengaturan dibatasi**, lalu ulangi.
3. Bubble biru muncul. Seret untuk memindahkan; sentuh untuk scan.

## Cara kerja singkat
- `ScanService` — layanan aksesibilitas: bubble (overlay aksesibilitas, tanpa izin overlay), `takeScreenshot()`, kotak seleksi.
- `CropLayout` — screenshot beku + kotak seleksi + tombol ✕ / Seluruh layar / ✓.
- `Ocr` — ML Kit Text Recognition (model ikut di APK, berjalan offline).
- `ResultActivity` — hasil OCR (bisa diedit) + tombol kirim ke platform + bagikan gambar.
- `Platforms` — daftar platform dan format URL-nya (mudah ditambah).

## Batasan
- Aplikasi yang memblokir screenshot (FLAG_SECURE) tidak bisa di-scan lewat bubble; pakai foto kamera/galeri dari menu utama.
- OCR kurang andal untuk rumus matematika, tulisan tangan, dan diagram. Gunakan "Bagikan GAMBAR soal".
- `takeScreenshot()` dibatasi sekitar 1 kali per detik oleh sistem.
- Gemini tidak menerima teks lewat URL, jadi teks disalin ke clipboard lalu Gemini dibuka (tempel manual).
- Tautan `?q=` ChatGPT/Perplexity/Copilot/Claude dapat berubah kapan saja oleh penyedianya.

## Menambah platform
Tambahkan satu baris di `Platforms.all` (file `Platforms.kt`):
`Platform("id", "Nama", "🔹", aiPrompt = true) { "https://situs.com/?q=$it" }`
